/*
 * 
 */
package org.datasyslab.geospark.utils;

import java.io.Serializable;
import java.util.Comparator;

import com.vividsolutions.jts.geom.Point;

// TODO: Auto-generated Javadoc
/**
 * The Class GemotryComparator.
 *
 * @author GeoSpark Team
 */
public abstract class GeometryComparator{

	/**
	 * Instantiates a new gemotry comparator.
	 */
	public GeometryComparator() {
		super();
	}
}